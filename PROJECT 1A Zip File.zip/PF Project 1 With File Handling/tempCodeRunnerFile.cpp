void printCarsForClient(int invID[], string invName[], int invModelYear[],
                        int invPopRating[], string invStatus[], int invPrice[],
                        int size);